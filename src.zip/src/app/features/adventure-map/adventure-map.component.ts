import { Component, ElementRef, ViewChild, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Observable, map } from 'rxjs';
import { MapGeneratorService } from '../../core/services/map-generator.service';
import { HeroMovementService } from '../../core/services/hero-movement.service';
import { TurnEngineService } from '../../core/services/turn-engine.service';
import { Tile } from '../../core/models/tile.model';
import { Hero } from '../../core/models/hero.model';

@Component({
  standalone: true,
  selector: 'app-adventure-map',
  imports: [CommonModule],
  template: `
    <canvas #canvas width="640" height="480"></canvas>

    <section class="ui">
      <p>Turn: {{ turn$ | async }}</p>
      <p>Movement: {{ movement$ | async }}</p>
      <button (click)="endTurn()">End Turn</button>
    </section>
  `,
})
export class AdventureMapComponent implements AfterViewInit {
  @ViewChild('canvas', { static: true }) canvas!: ElementRef<HTMLCanvasElement>;

  private ctx!: CanvasRenderingContext2D;
  private tileSize = 32;

  map!: Tile[][];
  hero: Hero = { x: 5, y: 5 };

  // Reactive bindings
  turn$: Observable<number>;
  movement$: Observable<number>;

  constructor(
    private mapGenerator: MapGeneratorService,
    private heroMovement: HeroMovementService,
    private turnEngine: TurnEngineService
  ) {
    this.turn$ = this.turnEngine.turnState$.pipe(
      map(state => state.currentTurn)
    );

    this.movement$ = this.turnEngine.turnState$.pipe(
      map(state => state.movementPoints)
    );
  }

  ngAfterViewInit(): void {
    this.ctx = this.canvas.nativeElement.getContext('2d')!;
    this.map = this.mapGenerator.generate(20, 15);
    this.draw();

    this.canvas.nativeElement.addEventListener('click', e =>
      this.onClick(e)
    );
  }

  endTurn(): void {
    this.turnEngine.endTurn();
  }

  private onClick(event: MouseEvent): void {
    const rect = this.canvas.nativeElement.getBoundingClientRect();
    const x = Math.floor((event.clientX - rect.left) / this.tileSize);
    const y = Math.floor((event.clientY - rect.top) / this.tileSize);

    const tile = this.map[y]?.[x];
    if (!tile || !tile.walkable) return;

    if (!this.turnEngine.consumeMovement()) return;

    this.hero = this.heroMovement.move(this.hero, tile);
    this.draw();
  }

  private draw(): void {
    this.ctx.clearRect(0, 0, 640, 480);

    for (const row of this.map) {
      for (const tile of row) {
        this.ctx.strokeRect(
          tile.x * this.tileSize,
          tile.y * this.tileSize,
          this.tileSize,
          this.tileSize
        );
      }
    }

    this.ctx.fillStyle = 'blue';
    this.ctx.fillRect(
      this.hero.x * this.tileSize + 4,
      this.hero.y * this.tileSize + 4,
      this.tileSize - 8,
      this.tileSize - 8
    );
  }
}
