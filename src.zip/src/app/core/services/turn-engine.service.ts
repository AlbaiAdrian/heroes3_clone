// core/services/turn-engine.service.ts
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { TurnState } from '../models/turn-state.model';
import { Hero } from '../models/hero.model';

const MAX_MOVEMENT = 10;

@Injectable({ providedIn: 'root' })
export class TurnEngineService {
  private state$ = new BehaviorSubject<TurnState>({
    currentTurn: 1,
    // movementPoints: MAX_MOVEMENT,
  });

  readonly turnState$ = this.state$.asObservable();

  get snapshot(): TurnState {
    return this.state$.value;
  }

  // consumeMovement(cost = 1): boolean {
  //   if (this.snapshot.movementPoints < cost) return false;

  //   this.state$.next({
  //     ...this.snapshot,
  //     movementPoints: this.snapshot.movementPoints - cost,
  //   });

  //   return true;
  // }

  endTurn(heroes: Hero[]): void {
    this.state$.next({
      currentTurn: this.snapshot.currentTurn + 1,
      // movementPoints: MAX_MOVEMENT,
    });
    heroes.forEach(hero => {
      hero.movementPoints = MAX_MOVEMENT;
    });
  }
}