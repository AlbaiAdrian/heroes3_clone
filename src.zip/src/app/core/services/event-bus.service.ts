// core/services/event-bus.service.ts
import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class EventBusService {
  private events$ = new Subject<{ type: string; payload?: unknown }>();

  emit(type: string, payload?: unknown): void {
    this.events$.next({ type, payload });
  }

  on() {
    return this.events$.asObservable();
  }
}