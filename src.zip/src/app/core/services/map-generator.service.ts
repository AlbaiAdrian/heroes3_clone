// core/services/map-generator.service.ts
import { Injectable } from '@angular/core';
import { Tile } from '../models/tile.model';

@Injectable({ providedIn: 'root' })
export class MapGeneratorService {
  generate(width: number, height: number): Tile[][] {
    return Array.from({ length: height }, (_, y) =>
      Array.from({ length: width }, (_, x) => ({
        x,
        y,
        walkable: true,
      }))
    );
  }
}