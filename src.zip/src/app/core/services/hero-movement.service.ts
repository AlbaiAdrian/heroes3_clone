// core/services/hero-movement.service.ts
import { Injectable } from '@angular/core';
import { Hero } from '../models/hero.model';
import { Tile } from '../models/tile.model';

@Injectable({ providedIn: 'root' })
export class HeroMovementService {
  move(hero: Hero, target: Tile): Hero {
    if (!target.walkable) {
      return hero;
    }

    return { ...hero, x: target.x, y: target.y };
  }
}