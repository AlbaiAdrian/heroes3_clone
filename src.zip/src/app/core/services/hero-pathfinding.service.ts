import { Injectable } from '@angular/core';
import { Tile } from '../models/tile.model';

@Injectable({ providedIn: 'root' })
export class HeroPathfindingService {

  /**
   * Returns a list of tiles from start (excluded) to target (included)
   */
  findPath(start: Tile, target: Tile, map: Tile[][]): Tile[] {
    const path: Tile[] = [];

    let x = start.x;
    let y = start.y;

    while (x !== target.x || y !== target.y) {
      if (x < target.x) x++;
      else if (x > target.x) x--;
      else if (y < target.y) y++;
      else if (y > target.y) y--;

      path.push(map[y][x]);
    }

    return path;
  }
}