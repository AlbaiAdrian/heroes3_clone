// core/models/turn-state.model.ts
export interface TurnState {
    currentTurn: number;
    // movementPoints: number;
    }