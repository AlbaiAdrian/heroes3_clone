  // core/models/hero.model.ts
  import { Tile } from './tile.model';

  export interface Hero {
    id: string;
    name: string;
    tile: Tile;
  
    movementPoints: number;
  }