// core/models/tile.model.ts
export interface Tile {
    x: number;
    y: number;
    walkable: boolean;
  }